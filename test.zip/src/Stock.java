import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class Stock {
  private final String tickerSymbol;
  private final Map<LocalDate, StockPrice> historicalPrices;
  private static final StockDataProvider dataProvider = new AlphaVantageStockDataProvider();

  public Stock(String tickerSymbol) throws UnknownStockException, IOException {
    this.tickerSymbol = tickerSymbol;
    this.historicalPrices = dataProvider.fetchHistoricalPrices(tickerSymbol);
  }

  public String getTickerSymbol() {
    return tickerSymbol;
  }

  public void addPrice(LocalDate date, double open, double high, double low, double close, long volume) {
    historicalPrices.put(date, new StockPrice(date, open, high, low, close, volume));
  }

  public StockPrice getPrice(LocalDate date) {
    return historicalPrices.get(date);
  }
}
