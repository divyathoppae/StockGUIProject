import java.io.IOException;
import java.time.LocalDate;
import java.util.Map;

public interface StockDataProvider {
  Map<LocalDate, StockPrice> fetchHistoricalPrices(String tickerSymbol) throws IOException, UnknownStockException;
}
