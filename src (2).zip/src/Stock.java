import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The Stock class represents a stock with its historical prices.
 */
public class Stock {
  private static final String apiKey = "TIKUGQGX5SGSNYAE";
  private final String tickerSymbol;
  private final Map<LocalDate, StockPrice> historicalPrices;

  /**
   * Constructs a Stock object with the
   * given ticker symbol and then with that
   * information, can get its data.
   *
   * @param tickerSymbol the ticker symbol of the stock
   * @throws UnknownStockException if the stock data can not
   *                               be found
   */
  public Stock(String tickerSymbol) throws UnknownStockException {

    this.tickerSymbol = tickerSymbol;
    this.historicalPrices = new HashMap<>();
    String message = updateStock();
    if (!message.equals("OK")) {
      throw new UnknownStockException(message);
    }

  }

  /**
   * Gets and updates the stock data from the API.
   *
   * @return a message indicating the result of the update
   * @throws RuntimeException if the API changed or no longer works
   * @throws IOException      if the file could not be read or the
   *                          if parts of the data could not be found
   */
  public String updateStock() {
    URL url = null;
    try {
      url = new URL("https://www.alphavantage"
              + ".co/query?function=TIME_SERIES_DAILY"
              + "&outputsize=full"
              + "&symbol"
              + "=" + this.tickerSymbol + "&apikey=" + apiKey + "&datatype=csv");
    } catch (MalformedURLException e) {
      throw new RuntimeException("the alphavantage API has either changed or "
              + "no longer works");
    }

    InputStream in = null;
    StringBuilder output = new StringBuilder();
    String fileOutput = "";

    try {
      in = url.openStream();
      int b;

      while ((b = in.read()) != -1) {
        output.append((char) b);
      }
    } catch (UnknownHostException e) {
      String currentDir = System.getProperty("user.dir");
      String relativePath = tickerSymbol + ".csv";

      // Construct the absolute file path
      String absolutePath = currentDir + "/" + relativePath;
      File file = new File(absolutePath);
      if (file.exists()) {
        String line;
        String csvDelimiter = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
          fileOutput = br.lines().collect(Collectors.joining("\r\n"));

        } catch (IOException f) {
          return "Couldn't read from file.";
        }
      }
    } catch (IOException e) {
      return "No price data found for " + this.tickerSymbol + "-" + e.toString();
    }

    String[] lines;
    if (fileOutput.isEmpty()) {
      lines = output.toString().split("\r\n");
      try {
        writeCsvFile(tickerSymbol + ".csv", lines);
      } catch (IOException e) {
        return "Unable to write csv file for stock with ticker symbol: " + tickerSymbol;
      }
    } else {
      lines = fileOutput.split("\r\n");
    }

    for (int i = 1; i < lines.length; i++) {
      String[] stockOutputLine = lines[i].split(",");

      StockPrice stockPrice = new StockPrice(
              LocalDate.parse(stockOutputLine[0]),
              Double.parseDouble(stockOutputLine[1]),
              Double.parseDouble(stockOutputLine[2]),
              Double.parseDouble(stockOutputLine[3]),
              Double.parseDouble(stockOutputLine[4]),
              Long.parseLong(stockOutputLine[5])
      );


      this.historicalPrices.put(LocalDate.parse(stockOutputLine[0]), stockPrice);
    }
    return "OK";
  }

  /**
   * Gets the ticker symbol of the stock.
   *
   * @return the ticker symbol of the stock
   */
  public String getTickerSymbol() {
    return tickerSymbol;
  }

  /**
   * Adds a price entry to the stock's historical prices.
   *
   * @param date   the date of the price entry
   * @param open   the opening price
   * @param high   the highest price
   * @param low    the lowest price
   * @param close  the closing price
   * @param volume the trading volume
   */
  public void addPrice(LocalDate date, double open, double high, double low,
                       double close, long volume) {
    historicalPrices.put(date, new StockPrice(date, open, high, low, close, volume));
  }


  /**
   * Gets the price of the stock on a specific date.
   *
   * @param date the date of the price entry
   * @return the stock price on the given date, or null if not available
   */
  public StockPrice getPrice(LocalDate date) {
    return historicalPrices.get(date);
  }

  /**
   * Writes the stock data to a CSV file.
   *
   * @param fileName the name of the file
   * @param lines    the lines of data to write
   * @throws IOException if an I/O error occurs
   */
  private void writeCsvFile(String fileName, String[] lines) throws IOException {
    try (FileWriter writer = new FileWriter(fileName)) {
      for (String line : lines) {
        writer.append(line).append("\n");
      }
    }
  }

}