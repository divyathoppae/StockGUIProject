import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Map;
import java.util.Scanner;

public class GUIStockController implements StockController, Features {
  private final Model model;
  private final GUIView view;
  private final Scanner scanner;

  public GUIStockController(Model model, GUIView view, InputStream in) {
    this.model = model;
    this.view = view;
    //view.setCommandListener(this);

    this.scanner = new Scanner(in);
  }

  public void start() {
    //view.setCommandListener(this);
    view.setFeatures(this);
    view.display();
  }


  @Override
  public void handleCreatePortfolio(String portfolioName) {
    if (portfolioName.isEmpty())
      return;
    try {
      model.createPortfolio(portfolioName);
      view.displayCreatePortfolio(portfolioName);
    } catch (InvalidPortfolioException e) {
      view.displayMessage("Error: " + e.getMessage());
    }
  }

  @Override
  public void handleFetchAndAddStock(String portfolioName, String tickerSymbol, LocalDate date, int quantity) {
    if (portfolioName.isEmpty())
      return;
    if (quantity <= 0) {
      view.displayMessage("Error: Quantity must be greater than zero.");
      return;
    }
    if (date == null)
      return;
    try {
      model.addStockToPortfolio(tickerSymbol, portfolioName, quantity, date);
      view.displayFetchAndAddStock(quantity, tickerSymbol);
    } catch (UnknownStockException | InvalidPortfolioException e) {
      view.displayMessage("Error: " + e.getMessage());
    }
  }

  @Override
  public void handleFetchAndRemoveStock(String portfolioName, String tickerSymbol, LocalDate date, int quantity) {
    if (portfolioName.isEmpty())
      return;
    if (quantity <= 0) {
      view.displayMessage("Error: Quantity must be greater than zero.");
      return;
    }
    if (date == null)
      return;

    try {
      model.removeStockFromPortfolio(portfolioName, tickerSymbol, quantity, date);
      view.displayFetchAndRemoveStock(quantity, tickerSymbol);
    } catch (UnknownStockException | InvalidPortfolioException | CannotSellException e) {
      view.displayMessage("Error: " + e.getMessage());
    }
  }

  @Override
  public void handlePortfolioValue(String portfolioName,LocalDate date) {
    if (portfolioName == null)
      return;
    if (date == null)
      return;

    try {
      double value = model.getPortfolioValue(portfolioName, date);
      view.displayPortfolioValue(portfolioName, date, value);
    } catch (UnknownStockException | InvalidPortfolioException e) {
      view.displayMessage("Error: " + e.getMessage());
    }
  }

  @Override
  public void handlePortfolioComposition(String portfolioName, LocalDate date) {
    try {
      Map<String, Double> composition = model.getPortfolioComposition(portfolioName, date);
      view.displayPortfolioComposition(composition, date);
    } catch (InvalidPortfolioException e) {
      view.displayMessage("Error: " + e.getMessage());
    }
  }



  @Override
  public void handleSavePortfolio(String portfolioName) {
    if (portfolioName == null) return;

    String filename = portfolioName + ".txt";
    try {
      model.savePortfolio(portfolioName, filename);
      view.displaySavePortfolio(filename);
    } catch (InvalidPortfolioException | IOException e) {
      view.displayMessage("Error: " + e.getMessage());
    }
  }

  @Override
  public void handleLoadPortfolio(String portfolioName) {
    if (portfolioName == null) return;

    try {
      model.retrievePortfolio(portfolioName);
      view.displayRetrievePortfolio(portfolioName);
    } catch (IOException e) {
      view.displayMessage("Failed to retrieve portfolio.");
    }
  }
}
