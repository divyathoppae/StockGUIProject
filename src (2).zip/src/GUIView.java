public interface GUIView extends View{
  void display();

  void setFeatures(Features features);
}
