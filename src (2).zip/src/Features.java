import java.time.LocalDate;

public interface Features {

  void handleCreatePortfolio(String portfolioName);

  void handleFetchAndAddStock(String portfolioName, String tickerSymbol, LocalDate date, int quantity);

  void handleFetchAndRemoveStock(String portfolioName, String tickerSymbol, LocalDate date, int quantity);

  void handlePortfolioValue(String portfolioName, LocalDate date);

  void handlePortfolioComposition(String portfolioName, LocalDate date);

  void handleSavePortfolio(String portfolioName);

  void handleLoadPortfolio(String portfolioName);
}
