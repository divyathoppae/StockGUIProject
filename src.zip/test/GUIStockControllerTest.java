public class GUIStockControllerTest {
}
